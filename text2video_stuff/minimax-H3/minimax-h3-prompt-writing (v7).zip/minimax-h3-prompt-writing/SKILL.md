---
name: minimax-h3-prompt-writing
description: Write or rewrite video generation prompts for MiniMax H3 (Hailuo 3), an omni-modal video+audio generator. Use whenever the user wants a MiniMax H3 / Hailuo 3 prompt, mentions T2VA, I2VA, FL2VA, L2VA, or Ref2VA, wants to convert a plain scene idea or script into H3's structured prompt format, needs to align first/last-frame keyframes with a video timeline, wants to write integrated_multimodal_description / overall_soundscape / non_diegetic_music fields, or needs a full-reference rewrite that uses Subject/Picture/Video/Audio reference labels for image, video, and audio references. Also use this to audit or fix an existing H3 prompt that isn't following the correct field names, section order, or timing notation.
---

# MiniMax H3 Prompt Writing

Turns a plain-language video idea (with or without reference images/video/audio) into a
production-ready MiniMax H3 prompt. H3 takes five input modes — T2VA, I2VA, FL2VA, L2VA, and
Ref2VA — and each one has a strict, specific output structure. Getting the field names, section
order, and timing notation exactly right matters a lot for generation quality, so always read the
matching reference file below rather than improvising from memory.

## Step 1 — Identify the input mode

Ask (or infer from what the user gives you):

| Mode | Trigger condition |
|---|---|
| **T2VA** | Text only, no reference images/video/audio |
| **I2VA** | One reference image = first frame only |
| **FL2VA** | Two reference images = first frame + last frame |
| **L2VA** | One reference image = last frame only (no first frame) |
| **Ref2VA** | Any combination of reference images/videos/audio used as identity, style, storyboard, editing-source, or audio references — not just clean first/last frames |

If the user supplies images/video/audio but it's unclear whether they're clean frame anchors or
looser references (a character photo, a source video to edit, a voice sample, etc.), treat it as
**Ref2VA** — it's the superset mode and handles everything the simpler modes can't.

### Model specs and input limits (check before writing)

| Category | Spec |
| --- | --- |
| Output duration | 4–15 seconds, whole seconds only (4s, 5s, 6s ... 15s) |
| Output aspect ratio | **First/Last Frame** (I2VA/FL2VA/L2VA): follows the uploaded image's own aspect ratio, not user-selectable. **T2VA** and **Ref2VA**: user-selected 21:9, 16:9, 4:3, 1:1, 3:4, or 9:16 — or, for Ref2VA only, an Auto mode that lets H3 pick the best ratio. |
| Output resolution | **768p mode** (available now): short edge 768px for 16:9–9:16 ratios; ~1MP total for wider ratios (e.g. 1536×672 at 21:9); can be upscaled to 1440p after the fact. **1440p/2K mode** (recommended): short edge 1440px for 16:9–9:16; ~3.7MP total for wider ratios (e.g. 2976×1248 at 21:9) — via H3-Regenerate-2K. |
| Output frame rate | 24 FPS |
| Output audio | Every generation includes native stereo audio (32 kHz) |
| Prompt length | Up to 7,000 characters |

**Input file specs:**
| Input | Formats | File size limit |
| --- | --- | --- |
| Video | H.264/AVC, H.265/HEVC (embedded audio: AAC, MP3) | 50 MB/file |
| Image | JPG, JPEG, PNG, WEBP, HEIC, HEIF | 30 MB/file |
| Audio | WAV, MP3 | 15 MB/file |

Limits apply per file, not to the combined upload size. API request body cap: 64 MB (prefer URL-based media for API workflows over inline upload).

**First/Last Frame mode (I2VA/FL2VA/L2VA) input caps:**
- Images: 0, 1, or 2. Dimensions [256, 5760]px; aspect ratio 5:2 to 2:5.
- 0 images → runs as T2VA instead.

**Ref2VA input caps** — if the user's assets exceed these, flag it before writing the prompt rather
than silently dropping references:
- Images: up to 9. Dimensions [256, 5760]px.
- Videos: up to 3 clips; 2–15s per clip; 15s total. Dimensions [256, 5760]px; aspect ratio 5:2 to 2:5.
- Audio: up to 3 clips; 2–15s per clip; 15s total. Audio must be paired with at least one image or
  video input — it can't be the sole reference.
- Mixed total across all reference types: up to 12 files.
- No image/video/audio input → runs as T2VA instead.

**Language support:** prompts and dialogue can be multilingual. Text-to-speech has its most reliable,
consistent coverage in Chinese, English, Japanese, Korean, French, German, and Spanish (part of a
stable 11-language tier). 40+ additional languages are usable with more variable reliability,
including Arabic, Thai, Indonesian, and Hindi — for dialogue-heavy prompts in one of these, mention
to the user that output quality may be less consistent than the core languages.

If the user hasn't specified an aspect ratio and it isn't obvious from context (a reference image's
own orientation, a platform they mentioned like "TikTok" or "YouTube"), pick a sensible default and
mention it — this is a fill-in-yourself detail, not one that needs asking, since guessing wrong here
still yields a usable prompt. Note that for I2VA/FL2VA/L2VA the aspect ratio isn't a free choice at
all — it's locked to the uploaded image's own ratio.

## Step 2 — Read the matching reference file

- **T2VA / I2VA / FL2VA / L2VA** → read `references/base-en.md` in full before writing anything.
  It defines the final prompt structure, the first-frame/last-frame alignment instruction syntax,
  and the three core fields.
- **Ref2VA (full-reference mode)** → read `references/ref-en.md` in full. It defines the six-section
  rewrite format (`subject_definitions`, `summary`, `retention_analysis`, `detailed_description`,
  `overall_soundscape`, `non_diegetic_music`) and the four reference label types.
  Note: Ref2VA still shares its shot/camera/speaker/dialogue mechanics with `base-en.md` — section
  5.1 of `ref-en.md` points back to those shared rules, so keep both open if the scene has dialogue,
  singing, or on-screen text.

Do not skip this step or reconstruct the format from memory/summary — the field names, label
syntax, and ordering are exact requirements, not stylistic suggestions, and small deviations
(wrong section order, missing blank line before the core fields, inventing a label type) will
produce a prompt H3 can't parse correctly.

## Step 3 — Gather what you need before writing

Check the checklist below against what the user actually gave you. Split it into two buckets:

**Things you can fill in yourself with creative judgment** — don't ask about these, just make a
strong choice and mention it briefly afterward:
- Camera motion type/amplitude/speed for a described action
- Environmental texture and sensory detail (lighting quality, background elements, small physical
  behaviors — hair moving, fabric swaying, incidental foreground/background activity)
- Shot pacing/cut points for a scene with no explicit shot list
- Style, when it's clearly derivable from reference images or genre cues in the text — but if a
  style/mood reference image itself contains readable text, logos, or brand marks that aren't part
  of what's being asked for, extract only the intended qualities (palette, texture, lighting,
  environment) and state explicitly that the reference's own text/logos should not be reproduced

**Things that change the output enough that guessing wrong wastes the user's generation** — ask
about these whenever the request doesn't specify them, rather than silently assuming:
- Which mode applies, when reference assets could plausibly serve more than one role (e.g. is this
  image a locked first frame, or just a loose identity/style reference?)
- Duration (H3 supports 4–15s) — pacing and shot count depend heavily on this
- Whether the scene should include spoken dialogue at all — don't assume silence and don't assume
  speech by default. If characters are shown talking, conversing, or arguing without the user
  specifying lines, ask whether they want actual scripted dialogue (and if so, the exact wording)
  or a dialogue-free scene played through body language, murmured/indistinct conversation, and
  reactions instead — these produce very different prompts.
- Exact dialogue/lyric wording if the user does want a character to speak or sing — never invent or
  paraphrase spoken lines, these must come from the user verbatim
- Any on-screen text that must appear exactly as written
- Sound design: always ask whether the user wants specific background music (mood/genre/instrumentation,
  or none) and whether there are particular sound effects they want called out in `overall_soundscape`
  beyond the obvious ambience (e.g. a specific object sound, an impact, a signature noise tied to the
  action) — don't silently invent the full sound design for a scene that has any real audio weight
  (action, impact, music-driven, or emotionally pivotal moments). For a quick, low-stakes scene where
  ambience is genuinely incidental, a brief mention of the default sound plan is enough instead of a
  full question, as long as the user has a clear chance to redirect it.
- For Ref2VA specifically: which reference asset should drive which role, if the user supplied
  several and the mapping isn't obvious (e.g. two people in one photo — who is Subject 1 vs. 2?)
- Whether any prop, weapon, or held object has hard constraints on its behavior (must not change
  length/shape, must not leave the character's hands, effects must stay anchored to one end/point) —
  ask if the scene involves a load-bearing prop or VFX source and the user hasn't specified this,
  since guessing wrong here tends to produce visible drift on exactly the shots the user cares most about
- For brand/logo films: the exact, complete list of permitted on-screen text (brand name, tagline,
  anything else) if it isn't already given — this becomes a hard boundary in the prompt

If the request is thin — just a one-line idea, or a reference image with no scene description —
don't default to a minimal, literal prompt. Ask 1-3 short, concrete questions (use `ask_user_input_v0`
if available, since tappable options are faster than typing) covering the highest-impact unknowns
from the second bucket above, then proceed once you have enough to write something specific rather
than generic. Skip asking if the user has already made their intent clear enough that a reasonable
default wouldn't materially change the result — the goal is to avoid wasted generations, not to
interrogate every request.

## Step 4 — Write the prompt, and make it good

A literal transcription of the user's one-line idea makes a flat, generic prompt. Your job is to
turn a short brief into a vivid, specific, well-directed shot — the way a director or DP would
develop a scene from a one-line pitch. For every shot, actively invent (within what the user
actually asked for and any reference assets provided):

- A clear visual anchor: specific lighting quality, time of day, color palette, or atmosphere —
  not just "outdoors" or "a room."
- At least one small, concrete piece of physical behavior beyond the headline action (a hand
  brushing something, hair catching wind, fabric settling, an incidental background detail) —
  this is what makes a shot feel alive rather than illustrative.
- A deliberate camera choice that serves the moment, not just a default static or push-in — vary
  motion type/amplitude/speed shot to shot to build a sense of pacing.
- A layered `overall_soundscape` that goes beyond the one obvious sound the scene implies (e.g. a
  garden isn't just birds — footsteps, fabric, wind through leaves, distant ambient life), built
  around whatever specific sound effects the user asked for in Step 3.
- If the user didn't want to specify music/SFX themselves, offer a specific `non_diegetic_music`
  suggestion (instrumentation, tempo, one dynamic shift) that fits the mood, rather than defaulting
  to `N/A` — flag it as a suggestion so the user can veto it if they'd rather have silence or their
  own reference audio.

### Physical realism — obey the world's own physics

Action, chase, and disaster scenes read as fake the moment a body ignores gravity, momentum,
collision, or its own limits. Before locking a shot's action beat, sanity-check it the way a
stunt coordinator would, not just a writer:

- **Solid things stop bodies.** A falling boulder, a collapsing wall, a swung object — these must
  visibly strike, block, graze, or force a dodge/flinch/stagger. Never let a character run "through"
  or alongside debris as if it were weightless set dressing. If a hit lands, show the physical
  consequence (stumble, being knocked off-line, a graze that costs a half-step), even if they keep
  moving.
- **Gaps, drops, and edges get a real decision, not a skip.** A chasm, pit, ledge, or hole a person
  couldn't casually stride across needs an explicit action that respects it: a hard stop and flinch
  back from the edge, a running leap with visible push-off and landing impact, a scramble/vault over
  a *narrow* gap only, or a fall/near-fall if that's the intent. Don't write a character "crossing"
  or "continuing forward" over a gap without describing how — a plain walk-through implies teleportation.
- **Momentum carries forward.** A sprinting character changing direction, stopping short, or
  dodging should show the cost of that momentum — an off-balance stagger, a skid, arms thrown out
  for balance, a stumble into a wall — not an instant, frictionless direction change.
- **Scale and timing stay plausible.** Match fall/impact speed to the size of what's falling
  (small debris is fast and sharp; a boulder or ceiling slab is heavier and lands with more force
  and a bigger reaction), and don't compress an action that needs a beat (a jump, a dodge, a
  recovery) into something instantaneous just to save words.
- **Environmental interaction is two-way.** If the scene has water, sand, mud, fire, smoke, or
  loose rubble underfoot, the characters' footing, breathing, or visibility should be affected by
  it (splashing, sinking slightly, coughing in smoke, slipping on scree) rather than moving through
  it unaffected.

This applies whenever a shot involves impact, falling, jumping, collision, chasing, or environmental
hazards — not just to disaster/action scenes generally. When in doubt, describe the physical cause
and its visible effect in the same beat, rather than stating only the outcome.

**Skin and surface realism.** For photoreal human subjects, especially close-up performance shots
(music videos, beauty/fashion content, dialogue close-ups), state the skin treatment explicitly
when it matters to the look: realistic matte or natural-finish skin with visible pores and texture,
rather than a glossy, over-smoothed, "AI-beautified" default. This is worth including whenever the
brief calls for a grounded, editorial, or documentary-real look rather than a deliberately polished
beauty/glamour treatment — flag it as a stated choice either way rather than leaving skin rendering
to chance.

### Emotional realism — faces and bodies react to what's actually happening

A character's expression should be a direct, specific response to the concrete stimulus in that
moment of the shot, not a generic mood applied uniformly across the whole scene. Before writing a
shot's emotional beat, identify the actual trigger (a threat appearing, a loss, a sound, a
realization, relief) and let the reaction match its size and type:

- **Name the trigger, then the reaction.** Don't write "she looks scared" in isolation — tie it to
  the cause in the same sentence: what she sees/hears/feels that produces the fear, and what her
  face and body specifically do about it (eyes widen, breath catches, she flinches back, shoulders
  pull in).
- **Match intensity to the stimulus, and let it change as the stimulus changes.** A distant rumble
  reads as wary alertness, not full terror; a boulder landing an arm's length away reads as a sharp,
  involuntary flinch or gasp; a direct hit or near-miss can go to a genuine scream, frozen shock, or
  a shaking aftermath. Don't hold one static "scared face" through an entire escalating sequence —
  let the expression escalate, spike, or release as the danger does.
- **Use the body, not just the face.** Real fear, grief, or shock shows in more than the eyes and
  mouth: a stumble, a hand grabbing for support or another person, shoulders curling inward,
  a held breath, weight shifting away from the threat. Layer at least one body cue with the facial
  one so it doesn't read as a static expression pasted onto a moving figure.
- **Differentiate characters' reactions when it fits who they are.** Two people facing the same
  threat don't have to emote identically — one might freeze while the other acts, one might mask
  fear faster than the other — when the scene and any established character traits support it.
  Don't default both to the same generic reaction shot for shot.
- **Let relief, grief, and aftermath breathe.** The emotional beat right after danger passes
  (a shaky exhale, eyes welling, a disbelieving laugh, hands trembling as they steady themselves)
  is as important as the fear beat itself — don't cut straight from danger to neutral continuation
  without a visible emotional release.
- **Ground it in the environment, not just the plot beat.** Smoke stinging the eyes, cold water
  making someone gasp, harsh light making someone squint and recoil, a sudden silence making
  someone go still and wary — environmental stimuli should produce their own small, specific
  reactions even when nothing is "happening" narratively in that instant.

This applies to any shot with an emotionally charged event — danger, loss, surprise, tenderness,
conflict — not only to fear in action scenes. When in doubt, write the stimulus and the reaction
as a single cause-and-effect beat rather than naming an emotion abstractly.

### Macro-structure template and non-narrative framing

For editorial, lookbook, trailer, or format-driven pieces, it helps to state the overall
macro-structure once, up front, before breaking it into shots — e.g. "Locked camera → typography
reveal → close-up → rapid look switches → hero ending." This gives the whole sequence a shared
destination and pacing shape to build shots against, the same way a musical form (verse/chorus) does
for a song — write it as a short arrow-chain naming each phase, then let the shot-by-shot breakdown
fill in each phase's specifics.

If the piece is explicitly not meant to carry a plot (a lookbook, a format reel, a pure style
showcase where shots don't need causal continuity with each other), say so directly — e.g. "this is
not narrative-driven." This is a deliberate exception to the usual expectation that beats connect
causally, and stating it up front prevents the model from inventing connective tissue between shots
that don't need any, while the physical/emotional realism rules still apply *within* each individual
shot.

### Shot count — scale cuts to duration, don't just stretch or cram

The number of shots should scale with the stated duration so each shot has enough screen time to
actually deliver its beat (a real wind-up, impact, and settle) rather than being a rushed flash-cut
or, in the other direction, a single shot padded out with idle motion to fill time. Use this as a
default pacing guide, and adjust within it for scene complexity (a dialogue-heavy or single-focus
scene can run fewer, longer shots than this range suggests; a densely eventful action scene can run
at the upper end):

| Duration | Default shot count |
| --- | --- |
| ~5s | 1–2 shots |
| ~10s | 3–4 shots |
| ~15s | 5–6 shots |

Distribute time across shots according to what each one needs to land, not evenly by default — a
shot establishing geography or a slower emotional beat can run longer than a quick reaction or
impact cut. Keep every shot's `[Shot N] At MM:SS.mmm, ...` timestamp consistent with the actual
pacing implied by this count, and don't let the last shot's content run past the stated total
duration.

### Prop and object identity lock — key objects need the same discipline as characters

Any prop that's central to the action (a weapon, a staff, a vehicle, a held object, a tool) drifts
in generation just as easily as a character's face does, and it doesn't get the automatic scrutiny
`subject_definitions`/`retention_analysis` gives people. Treat a scene-critical prop with the same
rigor:

- **Define its fixed attributes once, explicitly**, in `subject_definitions` or the opening of
  `detailed_description` — length, thickness, color, material, and any part that behaves specially
  (e.g. "a fixed-length dark slender performance staff, lit only at one end"). Restate the attribute
  that matters most (length, grip point, which end) at least once per shot if the prop is on screen
  through fast action, rather than assuming it carries over silently.
- **State how it's held/controlled and keep that consistent** — which hand(s), where on the object,
  and that the grip doesn't drift, multiply, or release unless the action explicitly calls for a
  drop, throw, or catch.
- **Tie any effect to the object's actual anchor point.** An effect (flame, glow, blade edge, spark
  trail) should originate from and move with the specific point on the prop that produces it — not
  detach, duplicate, or appear elsewhere on the body or object.
- **If the user's brief already includes hard constraints on the prop** (must not shorten/bend/
  duplicate/pass through the body, etc.), fold those into the shot descriptions themselves rather
  than only listing them separately — the more the constraint is reinforced in the actual action
  text, the more reliably it survives generation.

### Screen-space overlay elements (masks, frames, viewfinder/UI graphics)

Some scenes composite the actual footage inside a fixed on-screen frame — a viewfinder/binocular
mask, a phone/camera UI overlay, a letterbox or picture-in-picture border — where the frame itself
is a static graphic element and only the content inside it changes or transitions. Treat this frame
as its own locked layer, separate from the scene content:

- **State explicitly that the overlay stays geometrically fixed**: same position, scale, shape,
  edge treatment (vignette softness, border width), across every shot and every cut — only the
  image/content inside it may move, change, or transition.
- **Describe transitions as happening inside the frame**, not to the frame itself (a whip-blur cut,
  a rack focus, a snap-to-next-image) — the frame doesn't shift, warp, or re-crop when the content
  behind it changes.
- If on-screen text or graphics are locked to this overlay (e.g. a HUD label, a corner watermark
  that's part of the intended design, not an unwanted artifact), describe how it resolves in sync
  with a concrete visual event — coming into focus as the camera racks focus, fading in as a blur
  clears — rather than an independent, disconnected pop-in/fly-in/spin. Keep the motion restrained
  (a short fade or slide) unless the user asked for something more energetic.

**Motion-tracking overlays** (TouchDesigner/analysis-style bounding boxes, tracking lines, or data
readouts that follow a moving subject) are the inverse of the fixed-frame case above — here the
overlay *should* move, tracked to specific points in the footage rather than staying screen-fixed.
State this distinction explicitly: name what each box/line/label is tracking (a hand, a joint, a
moving object) and describe it updating position/scale as that point moves, rather than defaulting
to the geometrically-fixed treatment. If the graphic style has hard constraints (only simple closed
shapes, no color fill, no decorative nodes, no nesting one frame fully inside another), state them
as explicit rules the same way prop or overlay locks are stated elsewhere.

**Full-preservation overlay addition** is a specific `video editing` task: adding a graphic overlay
system to an existing video while changing nothing else about the footage itself. State plainly that
the subject, actions, environment, color palette, camera movement, duration, and frame rate are all
preserved exactly as in the source video, and that the overlay is the only new element — this framing
prevents the model from also altering lighting, color grade, or motion while it adds the requested
graphics.

**AR-style full-scene reskinning** is a third, distinct pattern from the two above: instead of
adding a graphic layer on top (overlay addition) or swapping out a subject's background
(green-screen compositing), the entire environment's visual style transforms — buildings, streets,
and objects all get reskinned into a new aesthetic — while its geometry, layout, camera path, and any
real diegetic elements (a visible hand, a cursor, real motion) stay locked in exact spatial
correspondence to the source footage. State explicitly which elements are geometry-locked (structure,
positions, camera movement, any real hand/interface elements) versus which are being restyled
(surface appearance, materials, color, added fantastical detail) — the shot should read as the same
place and the same camera move, just reskinned, not as a new environment loosely inspired by the old
one.

This is different from prop identity lock (above), which governs objects that exist *within* the
filmed scene — an overlay/mask is a compositing layer on top of the footage itself. Animating a
static graphic design (a poster, a card, a piece of packaging) into a "motion" version of itself is
the same pattern: the border, layout, palette, and framing elements that define the original design
stay locked exactly as given, and only specific elements within it animate.

**Graphic/UI reveal sound effects.** When text, icons, or graphic elements appear or animate on
screen — a title snapping in, a poster's typography animating, a UI element popping up — give that
reveal its own small, distinct sound (a light type-on click, a soft whoosh, a subtle chime) timed to
the exact moment of the visual reveal, the same way any other sound follows its visual cause. This
applies even to non-diegetic graphic elements that have no "real" physical source — the sound sells
the motion design the way a UI sound effect would.

**Cinematic title cards** (a film/trailer-style title, tagline, or credit text) are a related but
distinct case from the diegetic on-screen text covered in base-en.md §4.5 (signs, banners, neon
that physically exist in the scene). A title card isn't part of the world — it's graphic design
composited over the shot — so describe it as such:
- Give the typography its own material/lighting qualities (e.g. "wide-tracked cinematic type, not
  pure white, with restrained surface texture and a faint edge glow") rather than leaving it as bare
  text with no visual treatment.
- Animate it with a deliberate, describable motion tied to the scene's own light or camera event —
  emerging from shadow, catching a sweep of light, letter-spacing opening up, leaving a brief
  afterimage, flashing against a black frame — rather than a generic fade or an unmotivated pop-in.
- Ask the user for the exact title/tagline text if it hasn't been given (per the on-screen-text rule
  in Step 3) — Claude can propose the animation/treatment freely, but never invents the wording.

**Lyric-synced kinetic typography** (on-screen words that appear exactly as they're sung or spoken,
karaoke/music-video style) chains three existing rules together and needs all three applied at once:
the actual words must come from the user's exact lyrics/dialogue and live inside `<d>` per base-en.md
§4.4 (never invented or paraphrased); the on-screen text gets its own title-card treatment per the
rules above (material, motion, not bare text); and — the part that's easy to miss — the text's
appearance is tied to the specific word or phrase being vocalized at that instant, not to the music's
beat in general. State this explicitly in the shot: name which word triggers which piece of text
appearing, e.g. "as (S1) sings <d>[English] move fast</d>, the words 'MOVE FAST' snap onto screen in
bold radial type exactly on the word 'fast'" — the visual reveal and the vocal delivery need to be
the same instant, described as one cause-and-effect beat like any other sound-follows-cause pairing.

**Text-heavy motion graphics (title sequences, credit rolls, name/role cards)** carry extra risk of
the model garbling or duplicating text, so add explicit correctness constraints when a scene has
several distinct text elements: each name or role should appear exactly once (no duplicate role
assigned to the same name, no name repeated under two roles), spelled and cased exactly as given,
with no invented translation, no garbled/placeholder characters, and no script the user didn't ask
for. Fold this into the shot description or the scene's negative-constraints note.

**If a generation actually comes back with garbled text** (a real recurring H3 failure mode, not
just a risk to guard against upfront): the official fix is to supply the exact text as a reference
image instead of typed text, and state explicitly in the prompt that "this content must be
interpreted as an image, not processed as text." This is worth suggesting proactively whenever the
user is auditing/fixing a prompt whose prior generation had garbled or malformed on-screen text,
logos, or wordmarks.

**Closed text list for brand/logo films.** When a scene's only permitted text is a small, specific
set (a brand name, a tagline, nothing else), enumerate that exact set explicitly and state plainly
that no other readable text may appear anywhere in the film — this is a stronger, more useful
constraint than a generic "avoid garbled text" note, since it gives the model a hard boundary rather
than an open-ended risk to avoid. Ask the user for this exact list if a brand/logo film is requested
and the permitted text isn't already clear.

The inverse case — a **pure kinetic-typography or abstract-shape piece** where text or graphic form
*is* the entire visual subject and nothing else should appear — needs the same closed-boundary
treatment applied to the whole visual vocabulary, not just the text: enumerate the categories being
excluded explicitly (e.g. no people, scenery, photography, icons, logos, 3D objects, fixed UI
elements, borders, or grids) rather than only describing what should be present. An exhaustive
exclusion list reads as unusual for an ordinary scene, but for a deliberately minimal, single-subject
piece it's the right tool — it directly prevents the model from filling empty space with incidental
scene-like content.

**Transition vocabulary should match the genre**, especially for stylized title sequences, motion
graphics, or collage-style edits. Beyond the standard cut/cross-dissolve/fade/wipe from base-en.md
§4.2, a graphic or genre-driven sequence can call for a specific, varied transition palette (e.g.
circular wipes, hard-edge geometric masks, shape-driven cuts snapping to a beat) — list the actual
transition types you intend to use across the sequence, and if the style calls for something crisp
and graphic, say explicitly that soft dissolves/fluid morphs are excluded, rather than leaving
transition choice to chance shot to shot.

**Timed, beat-synced non_diegetic_music** — for trailers, title sequences, or any cut that must land
tightly on a musical beat, `non_diegetic_music` can include specific timestamped build points (e.g.
"a low drone and hi-hat in the first 2 seconds, the beat entering at 00:03, a bass figure at 00:06,
a short brass riff at 00:10, freezing on a held chord in the final 2 seconds") rather than only a
general instrumentation/tempo description — this is worth doing whenever cuts, reveals, or impacts
need to land on a specific musical hit, not just for ambient scoring.

**BPM-driven kinetic typography pulse** — for a kinetic-type or beat-heavy motion-graphics piece
where the visual animation should feel locked to the music's tempo throughout (not just at isolated
cue points), state the actual BPM explicitly in `non_diegetic_music` and describe the typography's
pop/scale/emphasis as happening on the beat as a recurring pattern (e.g. "at a driving 130 BPM, each
downbeat triggers a sharp scale-pop on the nearest character cluster") rather than only listing a
handful of one-off sync moments. Still anchor the most important individual hits with actual
timestamps within the shot descriptions — the BPM statement establishes the underlying pulse, and
the per-shot timestamps confirm where the biggest visual emphasis actually lands.

**Per-instrument sound-to-visual mapping** goes a step further than a single BPM pulse: assign a
distinct, consistent visual behavior to each element of the beat, and hold that mapping for the
whole piece (e.g. hi-hat rolls → rapid micro-vibration/fragmenting type; snare → sudden enlargement
and a hard cut; bass/808 hits → brief frame compression or a vertical/horizontal squeeze on type;
vocal accents → lip-sync, jaw movement, and forward gesture). State the mapping once, early in the
prompt, then apply it consistently shot to shot — this reads as a designed rhythmic system rather
than one-off effects. Useful for any dense music-video or kinetic-type piece, not only rap/trap.

**Text depth-layering with a protected zone.** When typography is meant to feel like a physical
layer around performers — sitting in foreground, midground, or background, partially occluded by
or occluding a subject — state that relationship explicitly (which layer the text sits on, what
occludes what) and set a hard protected zone: type must never cover the eyes or the primary facial
expression, even while it's allowed to overlap hair, shoulders, or clothing. This lets type feel
integrated with the performer without ever undermining the performance itself.

### Mixed-media style blending

Some scenes deliberately combine two visual registers in one shot — live-action footage with
hand-drawn/animated elements, photoreal with claymation, real footage with a game-UI overlay. When
this is the intent:
- State which elements belong to which register explicitly (e.g. "the kitchen and live actor are
  live-action; the small creature is hand-drawn, luminous 2D animation") so the model doesn't blend
  or normalize them into one uniform style.
- Describe how the two registers actually interact physically — does the drawn element cast light
  or shadow on the live-action surface, does it respond to real objects, does it stay confined to
  its own visual "layer"? Physical realism still applies across the blend: an interaction between a
  drawn character and a real mug should still involve contact, not passthrough.

**Selective/triggered transformation** is a specific sub-pattern: an in-frame action or object (a
pointer, a touch, a gesture, a diegetic hand entering frame) marks exactly which single element
converts to the other register, while everything else in the shot stays untouched. When writing
this:
- Name the trigger explicitly (e.g. "the pen tip touches the pendant") and state that only the
  touched/pointed-at object transforms — confirm the rest of the environment and any other objects
  remain in their original live-action state, so the model doesn't over-apply the transformation.
- If the same trigger recurs shot to shot (a hand holding a pen entering from off-frame each time),
  treat the trigger itself as a locked prop/identity per the prop-lock rules above — same grip, same
  object, same entry direction — so it reads as one consistent device across the sequence rather than
  a new incidental hand each time.
- Tie the transformation's timing to the trigger contact, not to the cut or a fixed duration — the
  object should begin converting at the moment of contact and can either complete within the shot or
  carry toward the next cut, whichever the pacing calls for.

**Flat graphic space treated as physical space** is another sub-pattern: a character interacts with
2D design elements (a poster frame, UI card edges, lettering, layout panels) as if they were real,
gripping frame edges, standing on lettering, launching between separate flat "spaces" as if they were
locations. Physical realism still governs these interactions even though the space itself is
graphic, not photographic:
- Describe each contact point concretely — gripping which edge, planting a foot on which line,
  landing on which letterform's surface — the same way a physical realism beat needs a real point of
  contact rather than an implied one.
- Name each transition between flat "spaces" as a discrete, describable action (springing out of one
  frame, cutting to a different graphic environment, returning to an origin card) rather than a vague
  dissolve between them, consistent with the match-cut/hard-cut anchoring guidance above.
- If the piece is styled after a recognizable graphic universe (posters, game UI, brand lettering),
  keep the negative-constraints note scoped to what that style shouldn't drift into (no unintended
  copyrighted characters or third-party insignia, no tone that breaks the flat-graphic aesthetic).

### Diegetic handheld camera (found-footage / phone-operator realism)

For a scene meant to feel like it was captured in the moment by someone actually holding the
camera — a phone video, found footage, an amateur recording — go beyond the standard `Shake
Slightly/Strongly` vocabulary and describe the camera as if a specific person is operating it:
hand tremor, hesitant refocusing/close-focus pulls as they react to what they're filming, exposure
shifting ("breathing") as backlight changes, coarser noise in shadow areas. If the operator is
meant to be a present, perceivable person, include their footsteps, breathing, or small vocal
reactions in `overall_soundscape` — this reinforces that the camera is a diegetic object being held
by someone, not a neutral cinematic rig.

**Glitch/echo effect layers over a real performance.** When a stylized effect (copier-style frame
offsets, delayed-frame echoes, scan misalignment, chromatic smear) is meant to sit on top of a real
performer's face or body, separate the two layers explicitly: state that the primary layer keeps
accurate lip sync, expression, and undistorted proportions, while the secondary glitch/echo layer
carries the stylized distortion without deforming the underlying face — this keeps the performance
readable while still delivering the aggressive visual treatment the style calls for.

When a scene has a strict tone boundary (e.g. unsettling but not frightening, "an event captured in
wonder, not a jump-scare"), fold that into the scene-specific negative-constraints note alongside
the usual drift-risk items — name the specific tone-breaking beats to avoid (jump scares, sudden
black frames, threatening lunges, aggressive imagery) rather than leaving "keep it gentle" implicit.

**Exaggerated VFX added around a real person or animal** (comedic sparks, explosions, impacts staged
near a real subject in a video-editing/compositing task) needs the same explicit boundary: state
that the subject's own appearance is preserved unchanged and that the effect must not be depicted as
harming them — the VFX should read as happening near or around the subject for comedic exaggeration,
not as an impact the subject suffers. This matters most for real people, pets, or other living
subjects sourced from an uploaded video or image, where an ambiguous prompt could be read as staging
injury.

### Green-screen / background-replacement compositing

A specific `video editing` task: removing a chroma-key (green/blue screen) background from a source
video and replacing it with a new environment, optionally guided by a second reference for the new
environment's style. This needs two things stated explicitly that a plain "swap the background"
instruction misses:

- **Relight the subject to match the new environment.** State the new environment's light
  direction, color temperature, and intensity, and describe the subject's lighting changing to match
  it (rim light from a new source, a color cast picking up the environment's palette, shadows falling
  in a direction consistent with the new scene) — a subject relit to match sells the composite; a
  subject retaining its original flat/neutral studio lighting reads as pasted on.
- **Make the environment react to the subject's motion**, not just sit behind it as a static plate:
  foreground elements should occlude the subject correctly as they move, ground-contact shadows
  should track footfalls, and any environmental motion (foliage, particles, light) should relate
  believably to the subject's position and movement rather than looping independently underneath.

Use `<Video N>` for the chroma-key source (the subject/action being kept) and either `<Video N>` or
`<Picture N>` for the new-environment reference depending on whether it's a video or still reference,
with task type `[video editing + reference generation]` in the summary. Note that the output
duration doesn't need to match either input video's duration — describe the actual target length.

### Generative motif systems (build the whole visual language from a small primitive set)

For abstract 2D/motion-graphics pieces meant to feel like one cohesive, generative brand system
(not a collage of separate graphic assets), name a small set of foundational shape primitives up
front (e.g. "a single dot, the letterform H, the numeral 3") and require that every other shape,
line, pathway, or transition in the piece reads as a transformation of those primitives rather than
an arbitrary new shape appearing. Each transformation still needs a clear visual cause and effect in
the same beat — the dot doesn't just "become" a line, it stretches, splits, or multiplies in a
describable way that the audience can follow — the same discipline as the match-cut/hard-cut
guidance above, just applied to abstract shape logic instead of live-action footage.

### Fire, light, and particle VFX — give the effect its own physical logic

Practical or magical effects (fire, embers, glowing light, smoke, water spray, dust) read as fake
the same way body physics do when they ignore their own material behavior. When a shot includes
one:

- **Layer the effect's structure**: a hot core color distinct from its outer edge (e.g. white-hot
  center fading to orange, or a bright core with a darker fringe), rather than a single flat color.
- **Give byproducts their own trajectory**: smoke rises and drifts with air movement, embers/sparks
  fall or scatter under gravity and air resistance, dust settles — these shouldn't hang static or
  vanish instantly.
- **Show decay, not just presence.** Fire, glow, or spark trails should visibly persist, dim, and
  fade after the source moves on (a swung flame leaves a brief afterglow before darkening to ember
  and ash/smoke), rather than snapping off the instant the shot describes the next beat.
- **Match effect scale and speed to the action producing it** — a fast strike makes a thin, sharp
  arc of light/fire; a slow sweep makes a broader, more diffuse trail.

### Sound must follow its cause, never anticipate it

Every discrete sound tied to a visible action — an impact, a swing, a footstep, an ignition — should
be described as occurring at or immediately after the action that causes it, never before. When
writing `overall_soundscape` (and any diegetic cues inside `detailed_description`), phrase sound
events as following the same trajectory and timing as the motion or object producing them (e.g. a
whoosh moves with a swinging object's actual path across the frame, an impact sound lands exactly
when contact happens) rather than as a generic layer floating independently of the visual timeline.

### Shot size and camera angle — choosing the feeling, not just the framing

`base-en.md` §4.3 covers *motion type* (how the camera moves) but not *shot size* (how much of the
subject fills the frame) or *camera angle* (where the camera sits relative to the subject's eyeline)
— both are describable in plain English within the shot text the same way motion is, and both carry
real emotional weight that's worth choosing deliberately rather than defaulting to "medium shot"
every time.

**Shot size**, from tightest to widest, and what each tends to do:
- **Extreme close-up** (fills the frame with eyes, lips, or a small detail): maximum intimacy or
  tension; used for a reaction that needs no other context to land.
- **Close-up** (head and a little shoulder): reads facial emotion clearly; the default for a beat
  that needs to be about *feeling* rather than *place*.
- **Medium close-up** (chest up): keeps expression readable while allowing a little gesture/hand
  movement into frame.
- **Medium shot** (waist up): balances person and immediate surroundings; the neutral default for
  dialogue and normal action.
- **Medium-long / cowboy shot** (mid-thigh up): keeps body language and some environment both
  visible; good for a beat where physical stance matters (a stand-off, a confident walk).
- **Wide/long shot** (full body, real sense of the space): establishes geography and scale;
  can read as small/isolated in a large space or as grounded/in-context depending on the scene.
- **Extreme wide/establishing shot** (subject small within a large environment): sets scale,
  location, and mood before narrowing in; can also read as insignificance or awe.

**Camera angle**, and the power/emotional read each one tends to carry:
- **Eye-level**: neutral, connective, the baseline every other angle deviates from for a reason.
- **Low angle** (camera below the subject, looking up): reads as power, dominance, threat, or
  triumph — makes the subject loom.
- **High angle** (camera above the subject, looking down): reads as vulnerability, smallness, or
  helplessness — makes the subject look diminished.
- **Dutch/canted angle** (camera tilted off the horizontal): reads as instability, disorientation,
  or wrongness — most effective used sparingly, as a deviation from level shots around it, not as a
  constant state.
- **Overhead/bird's-eye** (near-90°, looking straight down): reads as detachment, a "higher"
  vantage, or lays out spatial geography clearly.
- **Worm's-eye** (extreme low angle, near ground level): exaggerates scale and looming presence
  even further than a standard low angle.
- **Over-the-shoulder**: builds intimacy and connection in a conversation while keeping both
  parties' spatial relationship clear.

When a scene has a clear power dynamic, pairing a low angle on one character with a high angle on
the other in alternating shots (or across a shot/reverse-shot exchange) makes the imbalance legible
without a word of dialogue.

### Compound camera moves — combining two motions for a specific effect

`base-en.md`'s motion types can be combined within one shot's natural-English description — this is
distinct from a single motion type at a given amplitude/speed, and worth reaching for when a scene
needs an effect no single move produces alone. State both components explicitly, as an ordinary
compound sentence (e.g. "the camera pushes in while slowly panning left"), not as stacked labels.

- **Push In + Zoom Out simultaneously (opposite directions)** produces the "dolly zoom"/vertigo
  effect: the subject stays the same size while the background visibly stretches or compresses
  around them. This is a strong, recognizable effect — reserve it for a genuine moment of dread,
  vertigo, or a sudden shift in a character's understanding, not routine coverage.
- **Pedestal/Crane Up + Zoom Out** reveals scale and grandeur — a character or scene that seemed
  contained turns out to be part of something much larger. Common for an ending beat or a location
  reveal.
- **Arc Shot + Push In** circles the subject while tightening the frame, building tension or
  intensity as the angle keeps shifting — reads as more unstable/searching than a push-in alone.
- **Pan/Tracking + Zoom In on a moving subject** heightens that subject's importance mid-motion,
  useful for picking one figure out of a crowd or a chase.
- **Fast Pan ("whip pan")** used as a transition device (rather than settling on a new composition)
  reads as urgent, kinetic, or disorienting — often paired with a hard cut at the peak of the blur
  (see the match-cut guidance above).
- **Tracking/Truck at a low angle alongside a moving subject** keeps a sense of power or momentum
  attached to them as they move, rather than observing from a neutral height.

Match the compound move to the emotional beat it's serving (per the Emotional realism section
above) rather than combining moves for novelty — an unmotivated dolly zoom or whip pan reads as
showing off, not storytelling.

### Director-inspired compositional patterns

These are general, describable techniques associated with recognizable filmmaking approaches —
useful as a vocabulary for requesting a *type* of shot, not tied to any specific copyrighted film,
scene, or character:

- **Static, perfectly symmetrical one-point-perspective framing** (subject centered on a vanishing
  point, background lines converging toward them): reads as unsettling/clinical in a tense context,
  or as whimsical/storybook in a lighter one — the tone comes from lighting and subject, the
  technique itself is neutral.
- **A slow, quiet push-in on a lit face during a realization beat**: isolates a character's dawning
  understanding or emotional shift by giving the moment room and closing the distance gradually
  rather than cutting straight to a close-up.
- **A long, unbroken tracking/Steadicam shot following a subject through a changing space** (see
  Rapid repeated wardrobe/look cycling and Shot count above for how this interacts with duration):
  builds momentum and immersion by never releasing the subject to a cut.
- **A brief, extreme low-angle "hero" beat** on a character at a moment of triumph or resolve,
  contrasted against more neutral eye-level coverage around it, makes the beat land harder than if
  every shot used the same low angle.

Reach for these as options with a known effect, not as default choices — the goal is still to match
the technique to what the specific beat needs.

### Locked/static camera, when the scene calls for it

If the user asks for a locked, static, or fixed camera — or the scene is built around precise,
repeatable framing (a VFX-heavy match-cut, a transformation, a product-style demo) — say so
explicitly and specifically in the shot description (e.g. "the camera holds a fixed medium shot
with no pan, tilt, or push") rather than defaulting to the usual instinct to vary camera motion
shot to shot. Confirm there's no drift, whip, or incidental reframing anywhere in that shot's text.

### Hard-cut / match-cut transformations need a precise anchor

When two shots are joined by a hard cut timed to a specific in-motion moment (a match cut on
maximum motion blur, a costume swap, a scene-location swap disguised by smoke/motion) rather than
a normal cut between beats:

- **Name the exact anchor frame/moment** the cut occurs on (e.g. "at the frame where the arm's
  sweep reaches maximum motion blur across the chest") so the transition reads as one continuous
  motion interrupted, not two unrelated shots stitched together.
- **State explicitly what carries over and what changes** in the same beat — face, body position,
  and the direction/momentum of the triggering motion must match exactly across the cut; wardrobe,
  location, or lighting can change abruptly at that instant if that's the intent, but say so plainly
  rather than implying a gradual or morphing transformation (unless a gradual morph is actually what
  was asked for).
- **Lock what must not revert.** If a transformation shouldn't undo later in the scene (a costume
  change, an identity reveal), state once that it persists for the rest of the video, so later shots
  don't need to re-describe it but also won't drift back.

**Rapid repeated wardrobe/look cycling** (a lookbook, transformation reel, or "outfit change" edit
switching looks every second or two, many times in one video) is a repeated application of the same
anchor discipline above, but needs its own compact convention so the prompt doesn't balloon:
- State the identity-lock once, clearly, in `subject_definitions`/`retention_analysis` — face,
  body proportions, skin tone, hairstyle if it's staying constant — and don't re-describe it in every
  shot; instead give each shot only what's new (the outfit, the pose, the background graphic).
- Still name each look distinctly and give it a real anchor moment (a beat, a graphic transition) per
  the hard-cut guidance — a rapid sequence of swaps is still a sequence of individually anchored cuts,
  not a blur.
- If the count of looks is high relative to the duration (a look every ~1–1.5s), sanity-check this
  against the shot-count-by-duration table above — this kind of edit often runs at the dense end of
  that range or slightly beyond it by design, which is fine as long as it's a deliberate choice.

### Negative constraints, for scenes carrying real drift risk

Positive description alone often isn't enough to stop a generation from drifting on scenes with a
locked identity change, a load-bearing prop, or heavy VFX (fire, particles, transformation). For
these, add a short, specific list of what must not happen, placed at the end of `detailed_description`
or as a clearly separated closing note — drawn from the actual risks in *this* scene rather than a
generic catch-all: things like unintended extra characters/crowds/animals entering frame, the
locked prop changing length/shape/count or leaving the character's grip, identity or costume
reverting after a locked change, the effect (fire/light/particles) detaching from its anchor point
or persisting/vanishing unnaturally, on-screen text/logos/watermarks appearing, or camera behavior
(shake, whip, unmotivated cuts) that contradicts an explicitly locked shot. Keep this list scoped to
what's actually plausible for the specific scene — a generic wall of forty prohibitions dilutes the
ones that matter for this particular prompt.

Stay inside the guide's structure and rules while doing this — creativity applies to the content
you're filling in, never to the format itself:

- Field names, section order, and blank-line spacing must match the guide precisely.
- Camera motion: express as **motion type + amplitude + speed**, written as natural action within
  the sentence (not stacked labels) — see base-en.md §4.3 for the full vocabulary table.
- Speakers get stable IDs (S1), (S2)... reused across shots; non-vocal characters get none.
- Shots after the first need strictly increasing cut timestamps (`[Shot 2] At 00:03.500, ...`).
- `overall_soundscape` = ambience/physical/non-verbal sound only (never dialogue/singing/on-screen
  music) — use `N/A` only for total silence.
- `non_diegetic_music` = audience-only score (instrumentation/tempo/dynamics, no mood adjectives) —
  use `N/A` if none.
- For Ref2VA: assign `<Subject N>`, `<Picture N>`, `<Video N>`, `<Audio N>` labels correctly per
  ref-en.md §2 (each label type has a distinct role — don't create a standalone `<Picture N>` entry
  for an image that only defines a character's look, for example), and use the exact
  `fully_preserved` / `partially_preserved` / `attribute_transfer` / `weak_reference` /
  `fully_copy` / `partially_copy` / `reference` markers in `retention_analysis`.

## Step 5 — Self-check before handing it back

- Correct section order and exact field names for the mode
- Duration is a whole number of seconds within 4–15; aspect ratio is either correctly locked to the
  reference image (I2VA/FL2VA/L2VA) or a valid user-selected/Auto value (T2VA/Ref2VA)
- Ref2VA input counts (if applicable) are within limits: ≤9 images, ≤3 video clips (2–15s each,
  ≤15s total), ≤3 audio clips (2–15s each, ≤15s total, never audio-only), ≤12 files mixed total;
  I2VA/FL2VA/L2VA use 0–2 images only
- First line is the alignment instruction (I2VA/FL2VA/L2VA/Ref2VA-with-frame-anchors), blank line,
  then the core fields — never merged into one paragraph
- No invented reference-label types, no skipped `subject_definitions` entries for labels used later
- Dialogue inside `<d>` is verbatim and untranslated; non-dialogue prose is in English
- Timestamps strictly increasing and within the stated duration
- `overall_soundscape` and `non_diegetic_music` don't duplicate dialogue/singing/diegetic music
- Every impact, fall, jump, collision, or hazard beat shows a visible physical cause and effect
  (contact/consequence, momentum, a real decision at gaps/edges) rather than being skipped over
- Every emotionally charged beat ties a specific facial/body reaction to its actual trigger, with
  intensity that escalates or releases as the stimulus changes, rather than one static mood held
  uniformly through the shot or scene
- Shot count roughly matches the duration guide (~5s → 1–2 shots, ~10s → 3–4, ~15s → 5–6), adjusted
  for scene complexity rather than defaulting to one shot count regardless of duration
- Editorial/format-driven pieces state a macro-structure up front and, if non-narrative, say so
  explicitly rather than leaving the model to invent causal connections between shots
- Rapid repeated wardrobe/look-cycling states the identity-lock once rather than per shot, and each
  look still gets a real anchor moment per the hard-cut guidance
- Any scene-critical prop has its fixed attributes and grip/control stated explicitly, and any
  attached effect stays anchored to its actual source point rather than floating free
- Any screen-space overlay/frame (viewfinder mask, UI graphic, border) is stated as geometrically
  fixed across cuts, with transitions happening inside it rather than to it
- Text-heavy sequences (credits, name/role cards) have each name/role appearing exactly once with
  exact spelling/casing and no garbled or unintended-script text; any typography layered around a
  performer respects a protected zone that never covers the eyes or primary expression
- Style/mood reference images that contain their own text or logos are drawn on only for style
  qualities, with their embedded text/logos explicitly excluded from reproduction
- Beat-heavy pieces map distinct instrument/beat elements to distinct visual behaviors consistently,
  not just a single generic pulse; stylized glitch/echo layers over a real performer keep a separate
  undistorted primary layer for lip sync and expression
- Lyric-synced on-screen text (if present) names the exact word/phrase it appears on, matching the
  `<d>` vocal timing rather than a generic beat-sync
- Mixed-media shots state which elements belong to which visual register, and diegetic/found-footage
  camera work is described as a specific person's handling rather than generic shake
- Green-screen/background-replacement composites state the subject's relighting to match the new
  environment and describe the environment reacting to the subject's motion, not sitting static
- Brand/logo films with a closed text list state it explicitly with "no other text" boundary; abstract
  motion-graphics systems trace every shape back to a named small set of primitives with clear
  cause-and-effect transformations rather than arbitrary new shapes appearing
- Fire/light/particle effects (if present) show layered color/structure and visible decay, and
  sounds tied to visible actions are timed to follow, never precede, their cause
- Shot size and camera angle are chosen deliberately for the emotional/power effect each beat needs,
  not defaulted to medium-shot/eye-level throughout; any compound camera move matches a genuine
  emotional beat rather than being combined for novelty
- A locked/static camera is stated explicitly where the scene calls for it, and hard-cut/match-cut
  transitions name their anchor moment and state what carries over vs. what changes
- For scenes with real drift risk (locked identity/costume changes, load-bearing props, heavy VFX),
  a short scene-specific negative-constraints note is included rather than relying on positive
  description alone
- If auditing an existing prompt instead of writing a new one, check it against this same list and
  flag every deviation explicitly rather than silently fixing style choices that aren't errors

## Output

Present the finished prompt as a single copy-ready block (use a markdown code block). Briefly note
the mode chosen and any notable creative choices or assumptions (camera direction, sound design,
music suggestion, how ambiguous reference roles were resolved) — but keep the prompt itself clean
and pasteable, since that's what the user will send to H3. Offer to adjust any of those choices
rather than re-asking upfront for things you already made a reasonable call on.
